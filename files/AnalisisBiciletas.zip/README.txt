1. Dentro de la presentación se encuentran las visualizaciones, pero también las dejo por separado para poder verlas en tamaño completo.
2. Deje el código de R para que puedan ver y comentar mi proceso de análisis, estoy abierto a comentarios para poder aprender de nuevos enfoques de aproximación al problema en cuestión.

