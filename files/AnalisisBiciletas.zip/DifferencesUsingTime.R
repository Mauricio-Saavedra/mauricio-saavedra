# Empezaré por instalar los paquetes que voy a necesitar para mi analisis:
install.packages("tidyverse") # La madre de todos los paquetes jaja.
install.packages("skimr")     # Para estadistica.
install.packages("janitor")   # Para poderfacilitar limpieza y formateo.

# Ahora toca cargar estos paquetes:
library("conflicted")
library("tidyverse")
conflict_prefer("filter", "dplyr")
conflict_prefer("lag", "dplyr")
library("skimr")
library("janitor")
library("lubridate")

## Obtener la lista de nombres de archivos CSV en tu directorio
filesTotal <- list.files(pattern = "\\.csv$")


## Leer todos los archivos CSV y combinarlos en un solo tibble para facilitar su analisis
# dataFullYear <- map_dfr(filesTotal, ~read_csv(.x))
dataFullYear <- map_dfr(filesTotal, ~read_csv(.x) %>%
                          # Ayuda a estandarizar los fdatos flotantes de als coordenadas.
                          mutate(across(c(start_lat, end_lat, start_lng, end_lng), ~as.double(.))) %>%
                          drop_na() # Elimina todas las filas en las cuales haya algún valor nulo.
)


## Ver los primeros registros de tus datos combinados
head(dataFullYear) #%>%
  # select(member_casual)   # Esto esta así para poder ver el contenido de la columna para su posterior filtrado.
# }


# Ahora vamos a proceder midiendo el tiempo de uso de cada viaje realziado, para ello:
  # Primero vamos a sacar la difeencia en segundos entre los viajes:
# Calcular la duración del recorrido en segundos para posterioemente convertirlo:
dataFullYear <- dataFullYear %>%
  mutate(duracion_segundos = difftime(ended_at, started_at, units = "secs"))

head(dataFullYear) %>%
  select(duracion_segundos)

# Convertir los segundos a formato HH:MM:SS
dataFullYear <- dataFullYear %>%
  mutate(ride_lenght = as.period(duracion_segundos, units = "seconds"))

head(dataFullYear) %>%
  select(ride_lenght)


# Seguimos con las fechas, toca el momento de sacar el día de la semana que se inician los viajes,
  # supongo que para ver tendencias en la semana e identificar los días clave.
dataFullYear <- dataFullYear %>%
  mutate(day_of_week = wday(started_at))

head(dataFullYear) %>%
  select(day_of_week)


# Inspeccionar lo creado hasta el momento:
    # nrow(dataFullYear)  # Mostrar cuantas filas hay en el data frame (Lo dejo comentado porque 'dim' lo hace y mejor, pero no conocia esta función).
colnames(dataFullYear)  # Listar los nombres de las columnas.
dim(dataFullYear)  # Las dimenciones del data frame: filas | columnas 
summary(dataFullYear)  # Resumen estadístico de datos. Principalmente para números 


# Análisis descriptivo de ride_length (todas las cifras en segundos)
mean(dataFullYear$duracion_segundos) #promedio directo (longitud total del viaje / viajes)
median(dataFullYear$duracion_segundos) #número del punto medio en el conjunto ascendente de duraciones de viajes
max(dataFullYear$duracion_segundos) #viaje más largo
min(dataFullYear$duracion_segundos) #viaje más corto

# Ahora toca hacer las comparaciones entre los miembros y los casuales:
aggregate(dataFullYear$duracion_segundos ~ dataFullYear$member_casual, FUN = mean)
aggregate(dataFullYear$duracion_segundos ~ dataFullYear$member_casual, FUN = median)
aggregate(dataFullYear$duracion_segundos ~ dataFullYear$member_casual, FUN = max)
aggregate(dataFullYear$duracion_segundos ~ dataFullYear$member_casual, FUN = min)


## quiero ver la duración en minutos:
dataFullYear <- dataFullYear %>%
  mutate_at(vars(duracion_segundos), as.numeric) %>%
  mutate(duracion_minutos = duracion_segundos / 60)

aggregate(dataFullYear$duracion_minutos ~ dataFullYear$member_casual, FUN = mean)

# Ver el tiempo promedio de viaje cada día para miembros frente a usuarios ocasionales
aggregate(dataFullYear$duracion_segundos ~ dataFullYear$member_casual +
            dataFullYear$day_of_week, FUN = mean)

# analizar datos de número de pasajeros por tipo y día de la semana
dataFullYear %>%
    # Crea el campo de día de la semana usando wday():
  mutate(weekday = wday(started_at, label = TRUE)) %>%
    # Grupos por tipo de usuario y día laborable
  group_by(member_casual, weekday) %>%
    #calcula el número de viajes y la duración promedio
  summarise(number_of_rides = n()
#            ,average_duration = mean(ride_length)) %>% 		# Calcula la duración promedio
            ,average_duration = mean(duracion_segundos)) %>% 		# Calcula la duración promedio
  arrange(member_casual, weekday)	


# Ahora vamos a visualizar el número de viajes por tipo de usuario
dataFullYear %>% 
  mutate(weekday = wday(started_at, label = TRUE)) %>% 
  group_by(member_casual, weekday) %>% 
#  summarise(number_of_rides = n(), average_duration = mean(ride_lenght)) %>% 
  summarise(number_of_rides = n(), average_duration = mean(duracion_segundos)) %>% 
  arrange(member_casual, weekday)  %>% 
  ggplot(aes(x = weekday, y = number_of_rides, fill = member_casual)) +
  geom_col(position = "dodge")

  # Por la visualización puedo ver:
# 1.- Los Miembros usan la bicicleta en su mayoría para su uso entre semana, laboral.
# 2.- Los Casuales la usan para divertirse, son para su entretenimiento.


# Ahora visualizemos la duración promedio de cada viaje:
dataFullYear %>% 
  mutate(weekday = wday(started_at, label = TRUE)) %>% 
  group_by(member_casual, weekday) %>% 
#  summarise(number_of_rides = n(), average_duration = mean(ride_lenght)) %>% 
  summarise(number_of_rides = n(), average_duration = mean(duracion_segundos)) %>% 
  arrange(member_casual, weekday)  %>% 
  ggplot(aes(x = weekday, y = average_duration, fill = member_casual)) +
  geom_col(position = "dodge")

# Exportación a .csv
counts <- aggregate(dataFullYear$ride_lenght ~ dataFullYear$member_casual +
                      dataFullYear$day_of_week, FUN = mean)

write.csv(counts, file = '~/Desktop/avg_ride_length.csv')


## Acá voy a contar cuantos registros hay de miembros y de causales, quiero ver cuantos hay de cada uno para ver si no hay un sesgo:
# Suponiendo que tu conjunto de datos se llama 'data' y la columna de interés se llama 'tipo_usuario'
conteo <- table(dataFullYear$member_casual)
print(conteo)

conteo_df <- as.data.frame(conteo)
print(conteo_df)

### 1 casual 1,526,576  | Duración promedio: 22.92 minutos
### 2 member 2,773,391  | Duración promedio: 12.12 minutos